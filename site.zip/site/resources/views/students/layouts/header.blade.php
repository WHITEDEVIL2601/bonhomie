<nav class="navbar px-md-0 navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
	      <a class="navbar-brand" href="/bonhomie">Bon<i>homie</i></a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Menu
	      </button>

	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
			<li class="nav-item"><a href="/today-events" class="nav-link">Today's Events</a></li>

              <li class="nav-item"><a href="/events" class="nav-link">Events</a></li>
              <li class="nav-item"><a href="/notice" class="nav-link">Notice</a></li>
	          <li class="nav-item"><a href="/signin" class="nav-link">Sign In</a></li>
	          <li class="nav-item"><a href="/registration" class="nav-link">Sign Up</a></li>
            </ul>
	      </div>
	    </div>
</nav>
    <!-- END nav -->
