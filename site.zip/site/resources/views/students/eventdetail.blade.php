
    <h1>{{$event->event_name}}</h1>
    <h1>{{$event->category}}</h1>
    <h1>{{$event->description}}</h1>
    <h1>{{$event->date}}</h1>
    <h1>{{$event->time}}</h1>
    <h1>{{$event->rules}}</h1>
    <h1>{{$event->fee}}</h1>
    <h1>{{$event->prize}}</h1>
                                                                      
